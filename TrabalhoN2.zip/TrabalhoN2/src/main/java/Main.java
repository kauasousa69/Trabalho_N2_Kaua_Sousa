
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

public class Main {
    public static void main(String[] args) {
        CalculadoraModel model = new CalculadoraModel();
        CalculadoraView view = new CalculadoraView();
        CalculadoraController controller = new CalculadoraController(model, view);

        // Salvar operações ao fechar a aplicação
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            controller.salvarOperacoes();
        }));
    }
}
