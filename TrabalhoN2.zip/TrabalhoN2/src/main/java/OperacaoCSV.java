
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class OperacaoCSV {
    private static final String ARQUIVO_CSV = "operacoes.csv";

    public static void salvarOperacoes(List<String> operacoes) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARQUIVO_CSV))) {
            for (String operacao : operacoes) {
                bw.write(operacao);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
