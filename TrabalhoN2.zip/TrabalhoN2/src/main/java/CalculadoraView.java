
/**
 * Direitos Autorais e Propriedade Intelectual:
 *
 * @author Kauã Sousa <hacker.control3@gmail.com>
 * @date 3 de nov. de 2024
 */
/**
 *
 * @author kaua
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class CalculadoraView extends JFrame {
    private JTextField numero1 = new JTextField(10);
    private JTextField numero2 = new JTextField(10);
    private JTextField resultado = new JTextField(10);
    private JButton btnSomar = new JButton("Somar");
    private JButton btnSubtrair = new JButton("Subtrair");
    private JButton btnMultiplicar = new JButton("Multiplicar");
    private JButton btnDividir = new JButton("Dividir");
    private JButton btnExponenciar = new JButton("Exponenciar");
    private JButton btnRaizQuadrada = new JButton("Raiz Quadrada");
    private JButton btnPorcentagem = new JButton("Porcentagem");

    public CalculadoraView() {
        setLayout(new FlowLayout());
        add(new JLabel("Número 1:"));
        add(numero1);
        add(new JLabel("Número 2:"));
        add(numero2);
        add(new JLabel("Resultado:"));
        add(resultado);
        resultado.setEditable(false);
        add(btnSomar);
        add(btnSubtrair);
        add(btnMultiplicar);
        add(btnDividir);
        add(btnExponenciar);
        add(btnRaizQuadrada);
        add(btnPorcentagem);

        setSize(350, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public double getNumero1() {
        return Double.parseDouble(numero1.getText());
    }

    public double getNumero2() {
        return Double.parseDouble(numero2.getText());
    }

    public void setResultado(double resultado) {
        this.resultado.setText(String.valueOf(resultado));
    }

    public void addSomarListener(ActionListener listener) {
        btnSomar.addActionListener(listener);
    }

    public void addSubtrairListener(ActionListener listener) {
        btnSubtrair.addActionListener(listener);
    }

    public void addMultiplicarListener(ActionListener listener) {
        btnMultiplicar.addActionListener(listener);
    }

    public void addDividirListener(ActionListener listener) {
        btnDividir.addActionListener(listener);
    }

    public void addExponenciarListener(ActionListener listener) {
        btnExponenciar.addActionListener(listener);
    }

    public void addRaizQuadradaListener(ActionListener listener) {
        btnRaizQuadrada.addActionListener(listener);
    }

    public void addPorcentagemListener(ActionListener listener) {
        btnPorcentagem.addActionListener(listener);
    }
}
